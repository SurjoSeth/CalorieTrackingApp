package com.ai.calorieTrackerApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalorieTrackerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalorieTrackerAppApplication.class, args);
	}

}
