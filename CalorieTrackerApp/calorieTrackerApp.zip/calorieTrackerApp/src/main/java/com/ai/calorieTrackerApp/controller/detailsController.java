package com.ai.calorieTrackerApp.controller;

import com.ai.calorieTrackerApp.records.geminiRecord;
import com.ai.calorieTrackerApp.service.geminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.service.annotation.PostExchange;

import java.io.IOException;
@RestController
@RequestMapping("/gemini/ai")
public class detailsController {

    @Autowired
    private geminiService service;




    @PostMapping("gemini-pro/generateContent")
    public geminiRecord.GeminiResponse getCompletion(@PathVariable String model, @RequestBody geminiRecord.GeminiRequest request) {
        return service.getCompletion(request);
    }

    @PostMapping("gemini-pro-vision/generateContent")
    public geminiRecord.GeminiResponse getCompletionWithImage(@RequestBody geminiRecord.GeminiRequest request) {
        return service.getCompletionWithImage(request);
    }

    @PostExchange("imgdetail")
    public String imageDetail(@RequestBody String imgPath) throws IOException{
        String out = service.getCompletionWithImage(imgPath);
        System.out.println(out);
        return out.substring(8,out.length()-3);
    }
}
