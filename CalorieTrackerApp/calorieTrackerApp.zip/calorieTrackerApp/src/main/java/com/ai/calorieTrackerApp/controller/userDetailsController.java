package com.ai.calorieTrackerApp.controller;

import com.ai.calorieTrackerApp.models.userDetails;
import com.ai.calorieTrackerApp.models.userModel;
import com.ai.calorieTrackerApp.service.userDetailsService;
import com.ai.calorieTrackerApp.service.userModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class userDetailsController {

    private final userDetailsService service;

    @Autowired
    public userDetailsController(userDetailsService service) {
        this.service = service;
    }

    @PostMapping("/createUserDetails")
    public userDetails createUserDetails(@RequestBody userDetails details) {
//        System.out.println(details.getUserName());
        return service.createUserDetails(details);
    }


    @PutMapping("/updateUserDetails/{userId}")
    public userDetails updateUserDetails(@PathVariable Long userId, @RequestBody userDetails details) {
//        System.out.println(userId);
        return service.updateUserDetails(userId,details);
    }

}
