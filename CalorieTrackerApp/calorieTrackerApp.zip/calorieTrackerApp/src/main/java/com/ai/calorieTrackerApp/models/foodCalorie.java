package com.ai.calorieTrackerApp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "foodCalore")
public class foodCalorie {

    @Id
    private long foodId;

    private long userId;
    private  String itemType;
    private LocalDate date;

    private String itemName;

    private double quantity;

    private double calories;

    private double protein;

    private double carbohydrates;
    private double fat;

}
