package com.ai.calorieTrackerApp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "userDetails")
public class userDetails {
    @Id
    private long userId;

    private int age;

    private String gender;

    private double height;

    private double weight;

    private String goal;

    private double targetWeight;

    private double BMR;

    private String lifestyle;
}
