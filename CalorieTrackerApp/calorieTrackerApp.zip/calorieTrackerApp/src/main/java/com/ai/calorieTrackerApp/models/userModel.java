package com.ai.calorieTrackerApp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "userModel")
public class userModel {

    @Id
    private long userId;

    private String userName;


    private String emailId;

    private String password;

    private String contactNumber;


}
