package com.ai.calorieTrackerApp.repositories;

import com.ai.calorieTrackerApp.models.foodCalorie;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface foodCalorieRepo extends MongoRepository<foodCalorie, Long> {


        //method to find user by emailId and password returns Optional of User
    }

