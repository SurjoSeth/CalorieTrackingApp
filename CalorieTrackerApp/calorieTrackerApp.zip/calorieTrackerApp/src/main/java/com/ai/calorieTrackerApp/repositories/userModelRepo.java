package com.ai.calorieTrackerApp.repositories;

import com.ai.calorieTrackerApp.models.userModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface userModelRepo extends MongoRepository<userModel, Long> {

}