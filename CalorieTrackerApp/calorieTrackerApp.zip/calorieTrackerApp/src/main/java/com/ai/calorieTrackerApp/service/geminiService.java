package com.ai.calorieTrackerApp.service;

import com.ai.calorieTrackerApp.controller.geminiController;
import com.ai.calorieTrackerApp.records.geminiRecord;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.List;

@Service
public class geminiService {
    public static final String GEMINI_PRO = "gemini-pro";
    public static final String GEMINI_1_5_PRO = "gemini-1.5-pro-latest";
    public static final String GEMINI_PRO_VISION = "gemini-pro-vision";

    private final geminiController geminiInterface;



    @Autowired
    public geminiService(geminiController geminiInterface) {
        this.geminiInterface = geminiInterface;
    }

    public geminiRecord.ModelList getModels() {
        return geminiInterface.getModels();
    }

    public static void someStaticMethod(geminiService service) {
        // Now you can access geminiInterface through the service parameter
        geminiRecord.ModelList models = service.getModels();
    }

    public geminiRecord.GeminiCountResponse countTokens(String model, geminiRecord.GeminiRequest request) {
        return geminiInterface.countTokens(model, request);
    }

    public int countTokens(String text) {
        geminiRecord.GeminiCountResponse response = countTokens(GEMINI_PRO, new geminiRecord.GeminiRequest(
                List.of(new geminiRecord.Content(List.of(new geminiRecord.TextPart(text))))));
        return response.totalTokens();
    }

    public geminiRecord.GeminiResponse getCompletion(geminiRecord.GeminiRequest request) {
        return geminiInterface.getCompletion(GEMINI_PRO, request);
    }

    public  geminiRecord.GeminiResponse getCompletionWithModel(String model, geminiRecord.GeminiRequest request) {
        return geminiInterface.getCompletion(model, request);
    }


    public  geminiRecord.GeminiResponse getCompletionWithImage(geminiRecord.GeminiRequest request) {
        return geminiInterface.getCompletion(GEMINI_PRO_VISION, request);
    }

    public geminiRecord.GeminiResponse analyzeImage(geminiRecord.GeminiRequest request) {
        return geminiInterface.getCompletion(GEMINI_1_5_PRO, request);
    }

    public String getCompletion(String text) {
        geminiRecord.GeminiResponse response = getCompletion(new geminiRecord.GeminiRequest(
                List.of(new geminiRecord.Content(List.of(new geminiRecord.TextPart(text))))));
        return response.candidates().get(0).content().parts().get(0).text();
    }

//    public String getCompletionWithImage(String text, String imageFileName) throws IOException {
//        geminiRecord.GeminiResponse response = getCompletionWithImage(
//                new geminiRecord.GeminiRequest(List.of(new geminiRecord.Content(List.of(
//                        new geminiRecord.TextPart(text),
//                        new geminiRecord.InlineDataPart(new geminiRecord.InlineData("image/png",
//                                Base64.getEncoder().encodeToString(Files.readAllBytes(
//                                        Path.of("src/main/resources/", imageFileName))))))
//                ))));
//        System.out.println(response);
//        return response.candidates().get(0).content().parts().get(0).text();
//    }

    public String getCompletionWithImage(String imgPath) throws IOException {
        geminiRecord.GeminiResponse response = getCompletionWithImage(
                new geminiRecord.GeminiRequest(List.of(new geminiRecord.Content(List.of(
                        new geminiRecord.TextPart("Analyze this image of food, and in the form of a json format, provide the item name, the quantity of the food item in grams, calories in Kcal, protien, carbohydtrate and fat of each item. Dont put anything other than the mentioned properties."),
                        new geminiRecord.InlineDataPart(new geminiRecord.InlineData("image/png",
                                Base64.getEncoder().encodeToString(Files.readAllBytes(
                                        Path.of(imgPath))))))
                ))));
//        System.out.println(response);
        return response.candidates().get(0).content().parts().get(0).text();
    }

    public String analyzeImage(String text, String imageFileName) throws IOException {
        geminiRecord.GeminiResponse response = analyzeImage(
                new geminiRecord.GeminiRequest(List.of(new geminiRecord.Content(List.of(
                        new geminiRecord.TextPart(text),
                        new geminiRecord.InlineDataPart(new geminiRecord.InlineData("image/png",
                                Base64.getEncoder().encodeToString(Files.readAllBytes(
                                        Path.of("src/main/resources/", imageFileName))))))
                ))));
        System.out.println(response);
        return response.candidates().get(0).content().parts().get(0).text();
    }
}
