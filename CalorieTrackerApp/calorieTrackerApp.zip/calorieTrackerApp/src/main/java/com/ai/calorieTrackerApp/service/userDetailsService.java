package com.ai.calorieTrackerApp.service;

import com.ai.calorieTrackerApp.models.userDetails;
import com.ai.calorieTrackerApp.repositories.userDetailsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userDetailsService {

    private final userDetailsRepo repo;

    @Autowired
    public userDetailsService(userDetailsRepo repo){
        this.repo = repo;
    }

//    public void createUser() {
//        userModel user = new userModel();
//        user.setUserId(1L);
//        user.setUserName("Rohit");
//        user.setEmailId("rohit123@example.com");
//        user.setPassword("rohit123");
//        user.setContactNumber("9876543210");
//        repo.save(user);
//    }


    double bmrCalculator(userDetails details){
        double bmr=0.0;
        double w= details.getWeight();
        double h= details.getHeight();
        double a= details.getAge();
        if(details.getGender().equals("Male"))
            bmr = (66 + (13.7 * w) + (5 * h) - (6.8*a));
        else
            bmr=(655 + (9.6 *w)+(1.8*h)-(4.7*a));
        return bmr;
    }
    public userDetails createUserDetails(userDetails details) {
        details.setBMR(bmrCalculator(details));
        return repo.save(details);
    }

    public userDetails updateUserDetails(Long userId, userDetails details) {
        userDetails existingDetails = repo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        existingDetails.setWeight(details.getWeight());
        existingDetails.setHeight(details.getHeight());
        existingDetails.setAge(details.getAge());
        existingDetails.setGender(details.getGender());
        existingDetails.setBMR(bmrCalculator(existingDetails));
//        System.out.println(userId);

        return repo.save(existingDetails);
    }


}
