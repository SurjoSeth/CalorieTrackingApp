package com.ai.calorieTrackerApp.service;

import com.ai.calorieTrackerApp.models.userModel;
import com.ai.calorieTrackerApp.repositories.userModelRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userModelService {

    private final userModelRepo repo;

    @Autowired
    public userModelService(userModelRepo repo){
        this.repo = repo;
    }

//    public void createUser() {
//        userModel user = new userModel();
//        user.setUserId(1L);
//        user.setUserName("Rohit");
//        user.setEmailId("rohit123@example.com");
//        user.setPassword("rohit123");
//        user.setContactNumber("9876543210");
//        repo.save(user);
//    }

    public userModel createUser(userModel user) {
        return repo.save(user);
    }

}
